﻿namespace FluentTest
{
    using System;

    /// <summary>
    /// Interaction logic for MahMetroWindow.xaml
    /// </summary>
    [CLSCompliant(false)] // Because MetroWindow is not CLSCompliant
    public partial class MahMetroWindow
    {
        public MahMetroWindow()
        {
            this.InitializeComponent();
        }
    }
}