﻿using System.Reflection;

[assembly: AssemblyTitle("Fluent.Ribbon.Showcase")]
[assembly: AssemblyDescription("Showcase application for Fluent.Ribbon")]