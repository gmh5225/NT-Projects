﻿namespace FluentTest
{
    public partial class RibbonWindowWithoutRibbon
    {
        public RibbonWindowWithoutRibbon()
        {
            this.InitializeComponent();
        }
    }
}