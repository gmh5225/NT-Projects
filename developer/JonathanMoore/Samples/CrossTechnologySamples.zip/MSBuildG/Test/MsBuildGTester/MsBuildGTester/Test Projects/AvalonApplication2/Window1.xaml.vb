' Interaction logic for Window1.xaml
Partial Public Class Window1
    Inherits Window

    Public Sub New()
        InitializeComponent()
    End Sub

    ' Sample event handlers:
    'Private Sub OnLoaded(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles Me.Loaded

    'End Sub

    ' Event handler for a Button with a Name of Button1
    'Private Sub ButtonClick(ByVal sender As Object, ByVal e As RoutedEventArgs) Handles Button1.Click

    'End Sub


End Class
