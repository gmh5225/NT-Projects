Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("MoodOrb Sample")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("Microsoft")> 
<Assembly: AssemblyProduct("MoodOrb Sample")> 
<Assembly: AssemblyCopyright("Copyright @ Microsoft 2005")> 
<Assembly: AssemblyTrademark("")> 

'In order to begin building localizable applications, set <UICulture>CultureYouAreCodingWith</UICulture> in your
'.vbproj file inside a <PropertyGroup>.  For example, if you are using US english in your source files, set the
'<UICulture> to "en-US".  Then uncomment the NeutralResourceLanguage attribute below.
'Update the "en-US" in the line below to match the UICulture setting in the project file.
'<Assembly: NeutralResourcesLanguage("en-US", UltimateFallbackResourceLocation.Satellite)>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("4d89c681-48ec-461c-999c-a5dd4d6a1da3")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
