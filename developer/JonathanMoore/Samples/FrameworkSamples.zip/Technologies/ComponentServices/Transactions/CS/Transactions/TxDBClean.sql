IF EXISTS (SELECT * FROM sysdatabases WHERE name='TXDemoDB') DROP database TXDemoDB
GO

