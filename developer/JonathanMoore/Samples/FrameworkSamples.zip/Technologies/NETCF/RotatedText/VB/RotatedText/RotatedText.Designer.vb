﻿Partial Public Class RotatedText
    Inherits Form

End Class
