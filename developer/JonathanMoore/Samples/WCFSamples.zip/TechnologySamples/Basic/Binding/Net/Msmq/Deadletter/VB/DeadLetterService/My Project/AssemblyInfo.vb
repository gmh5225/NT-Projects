﻿Imports System
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("DeadLetterService")> 
<Assembly: AssemblyDescription("")> 
<Assembly: AssemblyCompany("MS")> 
<Assembly: AssemblyProduct("DeadLetterService")> 
<Assembly: AssemblyCopyright("Copyright © MS 2005")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: AssemblyConfiguration("")> 
<Assembly: AssemblyCulture("")> 
<Assembly: CLSCompliant(True)> 

<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("bc05bb12-fa61-4255-a51c-fe57c5252a50")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
