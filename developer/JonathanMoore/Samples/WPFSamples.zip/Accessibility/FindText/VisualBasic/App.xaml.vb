' Interaction logic for App.xaml
Partial Public Class App
    Inherits System.Windows.Application

End Class
