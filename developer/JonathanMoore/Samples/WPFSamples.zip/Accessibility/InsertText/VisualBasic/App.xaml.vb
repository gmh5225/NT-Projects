' Interaction logic for MyApp.xaml
Partial Public Class MyApp
    Inherits Application

End Class
