//-------------------------------------------------------------
// Description:	Automated test script
// Generator:	AutomatedScriptGenerator
// Date:	8/23/2006 4:19:56 PM
//-------------------------------------------------------------
using System;
using System.Windows;
using System.Windows.Automation;
namespace ExecuteScript
{
    class Script
    {
        public Script(ExecuteScriptClient clientApp)
        {
        }
    }
}
