using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;

namespace ScriptGeneratorTarget
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>

    public partial class App : Application
    {

        ///--------------------------------------------------------------------
        /// <summary>
        /// Constructor
        /// </summary>
        /// <remarks>
        /// Initializes components.
        /// </remarks>
        ///--------------------------------------------------------------------
        public App()
        {
            InitializeComponent();
        }

    }
}