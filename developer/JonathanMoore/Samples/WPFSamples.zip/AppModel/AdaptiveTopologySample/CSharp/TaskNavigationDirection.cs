using System;
using System.Collections.Generic;
using System.Text;

namespace AdaptiveTopologySample
{
    public enum TaskNavigationDirection
    {
        Forwards,
        Reverse
    }
}
