namespace AdaptiveTopologySample
{
    using System;

    public enum TaskResult
    {
        Finished,
        Canceled
    }
}
