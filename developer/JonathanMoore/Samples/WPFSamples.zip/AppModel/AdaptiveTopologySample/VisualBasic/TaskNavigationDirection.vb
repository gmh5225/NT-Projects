Imports System

Namespace AdaptiveTopologySample
    Public Enum TaskNavigationDirection
        Forwards = 0
        Reverse = 1
    End Enum
End Namespace


