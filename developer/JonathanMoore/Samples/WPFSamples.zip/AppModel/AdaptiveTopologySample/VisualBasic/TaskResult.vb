Imports System

Namespace AdaptiveTopologySample
    Public Enum TaskResult
        Canceled = 1
        Finished = 0
    End Enum
End Namespace


