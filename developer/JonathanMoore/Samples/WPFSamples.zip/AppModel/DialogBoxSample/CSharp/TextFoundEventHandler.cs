using System;

namespace DialogBoxSample
{
    public delegate void TextFoundEventHandler(object sender, EventArgs e);
}
