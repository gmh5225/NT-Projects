Imports System.Text.RegularExpressions

Public Class FindDialogBox
    Inherits Window

    Public Event TextFound As TextFoundEventHandler

    Public Sub New(ByVal textBoxToSearch As TextBox)
        Me.matchIndex = 0
        Me.Index = 0
        Me.Length = 0
        Me.InitializeComponent()
        Me.textBoxToSearch = textBoxToSearch
        AddHandler Me.textBoxToSearch.TextChanged, New TextChangedEventHandler(AddressOf Me.textBoxToSearch_TextChanged)
    End Sub

    Private Sub cancelButton_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        MyBase.Close()
    End Sub

    Private Sub criteria_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Me.ResetFind()
    End Sub

    Private Sub findNextButton_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        If (Me.matches Is Nothing) Then
            Dim pattern As String = Me.findWhatTextBox.Text
            If Me.matchWholeWordCheckBox.IsChecked.Value Then
                pattern = ("(?<=\W{0,1})" & pattern & "(?=\W)")
            End If
            If Not Me.caseSensitiveCheckBox.IsChecked.Value Then
                pattern = ("(?i)" & pattern)
            End If
            Me.matches = Regex.Matches(Me.textBoxToSearch.Text, pattern)
            Me.matchIndex = 0
            If (Me.matches.Count = 0) Then
                MessageBox.Show(("'" & Me.findWhatTextBox.Text & "' not found."), "Find")
                Me.matches = Nothing
                Return
            End If
        End If
        If (Me.matchIndex = Me.matches.Count) Then
            Dim result As MessageBoxResult = MessageBox.Show("Nmore matches found. Start at beginning?", "Find", MessageBoxButton.YesNo)
            If (result = MessageBoxResult.No) Then
                Return
            End If
            Me.matchIndex = 0
        End If
        Dim match As Match = Me.matches.Item(Me.matchIndex)

        Me.Index = match.Index
        Me.Length = match.Length
        RaiseEvent TextFound(Me, EventArgs.Empty)

        Me.matchIndex += 1
    End Sub

    Private Sub findWhatTextBox_TextChanged(ByVal sender As Object, ByVal e As TextChangedEventArgs)
        Me.ResetFind()
    End Sub

    Private Sub ResetFind()
        Me.findNextButton.IsEnabled = True
        Me.matches = Nothing
    End Sub

    Private Sub textBoxToSearch_TextChanged(ByVal sender As Object, ByVal e As TextChangedEventArgs)
        Me.ResetFind()
    End Sub

    Public Property Index() As Integer
        Get
            Return Me._index
        End Get
        Set(ByVal value As Integer)
            Me._index = value
        End Set
    End Property

    Public Property Length() As Integer
        Get
            Return Me._length
        End Get
        Set(ByVal value As Integer)
            Me._length = value
        End Set
    End Property

    Private _index As Integer
    Private _length As Integer
    Private matches As MatchCollection
    Private matchIndex As Integer
    Private textBoxToSearch As TextBox

End Class
