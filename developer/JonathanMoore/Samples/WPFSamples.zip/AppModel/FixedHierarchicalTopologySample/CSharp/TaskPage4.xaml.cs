namespace FixedHierarchicalTopologySample
{
    using System;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Navigation;

    /// <summary>
    /// Interaction logic for TaskPage4.xaml
    /// </summary>

    public partial class TaskPage4 : PageFunction<TaskResult>
    {
        public TaskPage4(TaskData taskData)
        {
            InitializeComponent();

            // Bind task state to UI
            this.DataContext = taskData;
        }

        void backButton_Click(object sender, RoutedEventArgs e)
        {
            // Go to previous task page
            this.NavigationService.GoBack();
        }

        void cancelButton_Click(object sender, RoutedEventArgs e)
        {
            // Cancel the task and don't return any data
            OnReturn(new ReturnEventArgs<TaskResult>(TaskResult.Canceled));
        }

        void finishButton_Click(object sender, RoutedEventArgs e)
        {
            // Finish the task and return bound data to calling page
            OnReturn(new ReturnEventArgs<TaskResult>(TaskResult.Finished));
        }
    }
}