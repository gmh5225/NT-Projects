namespace FixedLinearTopologySample
{
    using System;

    public enum TaskResult
    {
        Finished,
        Canceled
    }
}
