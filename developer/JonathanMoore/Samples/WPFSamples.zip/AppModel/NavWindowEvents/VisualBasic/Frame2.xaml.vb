Imports System
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Documents
Imports System.Windows.Navigation
Imports System.Windows.Shapes

Namespace NavWindow_Events_VB
  Partial Class Frame2
    Inherits Page
    ' ...
  End Class

End Namespace