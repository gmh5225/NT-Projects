using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;

namespace CustomApplicationClient
{
    public partial class app : CustomApplicationLibrary.CustomApplication
    {

  }
}