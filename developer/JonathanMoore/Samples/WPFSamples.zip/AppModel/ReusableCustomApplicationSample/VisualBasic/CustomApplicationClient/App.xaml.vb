' Interaction logic for App.xaml
Partial Public Class App
    Inherits CustomApplicationLibrary.CustomApplication

End Class
