using System;
using System.Windows;
using System.Windows.Controls;

namespace SingleInstanceDetection
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}