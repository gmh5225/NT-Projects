using System;
using System.Windows;

namespace SizingPrecedenceSampleCSharp
{
    public partial class SizingWindow : System.Windows.Window
    {
        public SizingWindow()
        {
            InitializeComponent();
        }
    }
}