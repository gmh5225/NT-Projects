' Interaction logic for SizingWindow.xaml
Partial Public Class SizingWindow
    Inherits System.Windows.Window

    Public Sub New()
        InitializeComponent()
    End Sub

End Class
