Imports System.Windows

Public Class ChildWindow
    Inherits Window

    Public Sub New()
        Me.InitializeComponent()
    End Sub

End Class